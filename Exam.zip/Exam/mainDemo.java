
import java.util.*;
import java.math.*;
import java.io.*;
import java.lang.*;


public class mainDemo
{
	
	public static void main(String[] args)
	{
		
		China Dumplings = new China("old", "dry", "complex", "Buddhists", true,  "Dumplings");
		System.out.println(Dumplings.getInfo());		
	} // End PSVM
	
	
	
} // END class MyInhertanceDemo
